﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CasePagamentos.Entites
{
	public class VendasProvisionadas
	{
		public long CpfCliente { get; set; }
		public decimal ValorDaVenda { get; set; }
		public int QuantidadeParcelas { get; set; }
	}
}
