﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CasePagamentos.Entites
{
	public class EmprestimoResult
	{
		public int CodigoParceiro { get; set; }
		public bool StatusEmprestimo { get; set; }
		public decimal LimiteEmprestimo { get; set; }
	}
}
