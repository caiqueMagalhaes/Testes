﻿using CasePagamentos.Entites;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CasePagamentos
{
	
	public class App
	{
		public IEnumerable<EmprestimoResult> EnfileiramentoMensageria(int codigoParceiro, long cpf, IEnumerable<VendasProvisionadas> vendasProvisionadas) 
		{

			
			 //chama fila na AWS 
			   
			 //recebe dados processados na aws



			  return null;
		}
	}
}
