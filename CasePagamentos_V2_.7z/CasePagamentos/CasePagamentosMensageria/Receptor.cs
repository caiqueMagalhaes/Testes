﻿using CasePagamentos.Entites;
using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Text;

namespace CasePagamentosMensageria
{
	public class Receptor
	{
		public void Consumir() 
		{
			var factory = new ConnectionFactory() { HostName = "AWS" };

			using (var connection = factory.CreateConnection()) 
			{
				using (var channel = connection.CreateModel())
				{
					channel.QueueDeclare(queue: "order",
										 durable: false,
										 exclusive: false,
										 autoDelete: false,
										 arguments: null);

					var data = channel.BasicGet("order", true);

					var json = Encoding.UTF8.GetString(data.Body.ToArray());
					var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<EmprestimoResult>(json);

					Console.Write(obj);

				}
			}
		}
	}
}
