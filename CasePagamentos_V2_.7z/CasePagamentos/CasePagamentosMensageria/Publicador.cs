﻿using CasePagamentos.Entites;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Text;

namespace CasePagamentosMensageria
{
	public class Publicador
	{
		public void Publicar(VendasProvisionadas objvendas)
		{
			var factory = new ConnectionFactory() { HostName = "AWS" };

			using (var connection = factory.CreateConnection())
			using (var channel = connection.CreateModel())
			{
				channel.ConfirmSelect();
				channel.BasicAck += Evento_Confirmacao;
				channel.BasicAck += Evento_NaoConfirmacao;

				channel.QueueDeclare(queue: "order",
									 durable: false,
									 exclusive: false,
									 autoDelete: false,
									 arguments: null);

				var json = Newtonsoft.Json.JsonConvert.SerializeObject(objvendas);
				var body = Encoding.UTF8.GetBytes(json);

				channel.BasicPublish(exchange:"",
									 routingKey: "order",
									 basicProperties: null,
									 body: body);

				Console.WriteLine("Mensagem Enviada!");
				
			}
			
		}

		private void Evento_Confirmacao(object sender, BasicNackEventArgs e)
		{
			Console.WriteLine("Ack");
		}


		private void Evento_NaoConfirmacao(object sender, BasicNackEventArgs e) 
		{
			Console.WriteLine("Nack");
		}


	}
}
