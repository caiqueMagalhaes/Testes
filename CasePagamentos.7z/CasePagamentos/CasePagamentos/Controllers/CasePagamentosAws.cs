﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using CasePagamentos.Entites;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace CasePagamentos.Controllers
{
	[ApiController]
	[Route("[controller]")]
	public class CasePagamentosAws : ControllerBase
	{
		
		private readonly ILogger<CasePagamentosAws> _logger;
		public CasePagamentosAws(ILogger<CasePagamentosAws> logger)
		{
			_logger = logger;
		}

		[HttpGet("ObterAvaliacaoDeCredito")]
		[ProducesResponseType(typeof(IEnumerable<EmprestimoResult>), (int)HttpStatusCode.OK)]
		public async Task<IActionResult> ObterAvaliacaoDeCredito([FromBody] int codigoParceiro,long cnpj, IEnumerable<VendasProvisionadas> vendasProvisionadas ) 
		{

			var retornoEmprestimos = new List<EmprestimoResult>();
			return Ok(retornoEmprestimos);
		}
	}
}
