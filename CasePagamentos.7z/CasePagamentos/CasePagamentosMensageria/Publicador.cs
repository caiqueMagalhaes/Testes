﻿using System;

namespace CasePagamentosMensageria
{
	public class Publicador
	{
	}
}
